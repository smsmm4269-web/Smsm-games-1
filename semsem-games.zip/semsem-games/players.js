'use strict';
// مجموعة لاعيبة خيالية (أسماء وتصنيفات مولّدة) — لا علاقة لها بلاعيبة حقيقيين.
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const FIRST = ['كريم','عمر','يوسف','زياد','آدم','مالك','سيف','تامر','هيثم','وليد','باسل','ياسين','رامي','عادل','شادي','مازن','نادر','فادي','حازم','مصطفى','ماجد','سامح','أنس','جاسر','عزيز','طارق','هاني','لؤي','بدر','رائد','إياد','قيس','منذر','صبري','جلال','نبيل','فارس','غسان','ثابت','وسام'];
const LAST = ['الكاشف','الدسوقي','الجمّال','العطار','الفخراني','الصاوي','النجار','الطنطاوي','السكري','الحداد','المهدي','سلطان','قطب','عيسوي','رضوان','الرفاعي','الشافعي','البنا','عزب','حبيب','زكي','فهمي','نصار','الخولي','المرسي','بدوي','شعراوي','الجزار','دياب','حمزاوي'];
const PLAN = { GK: 9, RB: 9, CB: 16, LB: 9, CM: 16, CAM: 9, RW: 9, LW: 9, ST: 13 };
const tierOf = (r) => (r >= 92 ? 'legend' : r >= 87 ? 'gold' : r >= 80 ? 'silver' : 'bronze');
const priceOf = (r) => Math.max(2, Math.round(((r - 66) ** 2) / 12));

function buildPool() {
  const rnd = mulberry32(20261028);
  const used = new Set();
  const pool = [];
  let n = 0;
  for (const [pos, count] of Object.entries(PLAN)) {
    for (let k = 0; k < count; k++) {
      const r = k < 3 ? 70 + k : 70 + Math.floor(Math.pow(rnd(), 1.7) * 26); // أول 3 كروت رخيصة تضمن إن التشكيلة تتكمل
      let name;
      do { name = FIRST[Math.floor(rnd() * FIRST.length)] + ' ' + LAST[Math.floor(rnd() * LAST.length)]; } while (used.has(name));
      used.add(name);
      pool.push({ id: 'p' + n++, name, pos, r, price: priceOf(r), tier: tierOf(r) });
    }
  }
  return pool;
}
module.exports = { buildPool };
