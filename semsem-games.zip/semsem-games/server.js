'use strict';
// سمسم جيمز — سيرفر اللعبة: HTTP + WebSocket + SQLite (كله مدمج في Node، بدون مكتبات خارجية)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { handleUpgrade } = require('./miniws');
const { buildPool } = require('./players');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';
fs.mkdirSync(DATA_DIR, { recursive: true });

// ───────────── قاعدة البيانات ─────────────
const db = new DatabaseSync(path.join(DATA_DIR, 'semsem.db'));
db.exec(`
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  salt TEXT NOT NULL, hash TEXT NOT NULL,
  coins INTEGER NOT NULL DEFAULT 100,
  wins INTEGER NOT NULL DEFAULT 0, losses INTEGER NOT NULL DEFAULT 0, draws INTEGER NOT NULL DEFAULT 0,
  created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS matches(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  p1 TEXT, p2 TEXT, p1_id INTEGER, p2_id INTEGER,
  s1 INTEGER, s2 INTEGER, winner INTEGER, vs_bot INTEGER NOT NULL DEFAULT 0, created INTEGER);
`);
const q = {
  userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
  userById: db.prepare('SELECT * FROM users WHERE id = ?'),
  insertUser: db.prepare('INSERT INTO users(username,salt,hash,created) VALUES(?,?,?,?)'),
  insertSession: db.prepare('INSERT INTO sessions(token_hash,user_id,created) VALUES(?,?,?)'),
  sessionUser: db.prepare('SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.created > ?'),
  delSession: db.prepare('DELETE FROM sessions WHERE token_hash = ?'),
  purgeSessions: db.prepare('DELETE FROM sessions WHERE created <= ?'),
  applyResult: db.prepare('UPDATE users SET wins=wins+?, losses=losses+?, draws=draws+?, coins=coins+? WHERE id=?'),
  insertMatch: db.prepare('INSERT INTO matches(p1,p2,p1_id,p2_id,s1,s2,winner,vs_bot,created) VALUES(?,?,?,?,?,?,?,?,?)'),
  board: db.prepare('SELECT username, wins, losses, draws, coins FROM users ORDER BY wins DESC, coins DESC, id ASC LIMIT 20'),
  history: db.prepare('SELECT p1,p2,p1_id,p2_id,s1,s2,winner,vs_bot,created FROM matches WHERE p1_id = ? OR p2_id = ? ORDER BY id DESC LIMIT 10'),
};
const SESSION_MS = 30 * 24 * 3600 * 1000;
q.purgeSessions.run(Date.now() - SESSION_MS);

const publicUser = (u) => ({ id: u.id, username: u.username, coins: u.coins, wins: u.wins, losses: u.losses, draws: u.draws });
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');
function hashPassword(pw, salt) { return crypto.scryptSync(pw, salt, 64).toString('hex'); }
function checkPassword(pw, user) {
  const a = Buffer.from(hashPassword(pw, user.salt), 'hex');
  const b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function newSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  q.insertSession.run(sha(token), userId, Date.now());
  return token;
}
const userFromToken = (token) => (typeof token === 'string' && token.length === 64 ? q.sessionUser.get(sha(token), Date.now() - SESSION_MS) : null);

// ───────────── منطق اللعبة ─────────────
const POOL = buildPool();
const SLOTS = ['GK', 'RB', 'CB1', 'CB2', 'LB', 'CM1', 'CM2', 'CAM', 'RW', 'ST', 'LW'];
const slotPos = (s) => s.replace(/\d/, '');
const BUDGET = 200, AUCTION_MS = 20000, SOLO_MS = 10000, EXTEND_MS = 8000, BETWEEN_MS = 2600, START_MS = 1800, DC_MS = 30000, MIN_RESERVE = 2;
const REACTIONS = ['😂', '🔥', '👏', '😎', '😡', '🤝'];

const freeSlot = (p, pos) => SLOTS.find((s) => slotPos(s) === pos && !p.squad[s]);
const emptyCount = (p) => SLOTS.filter((s) => !p.squad[s]).length;
const maxAllowed = (p) => p.budget - (emptyCount(p) - 1) * MIN_RESERVE; // لازم يفضل ليك حد أدنى لباقي الخانات
const canBuy = (p, card) => !!freeSlot(p, card.pos) && maxAllowed(p) >= card.price;
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

const online = new Map();      // userId -> { conn, user }
const userMatch = new Map();   // userId -> Match
let queue = [];                // userIds
const invites = new Map();     // `${fromId}>${toId}` -> expiry timer

class Match {
  constructor(a, b) {
    this.id = crypto.randomBytes(6).toString('hex');
    this.players = [a, b].map((x) => ({
      userId: x.bot ? null : x.userId, name: x.name, bot: !!x.bot, conn: x.bot ? null : x.conn,
      budget: BUDGET, squad: {}, skipped: false, dcTimer: null, bt: null,
    }));
    this.deck = shuffle(POOL.slice());
    this.phase = 'starting'; this.round = 0; this.unsold = 0; this.auction = null; this.last = null; this.result = null; this.over = false;
    this.t = null; this.nt = null;
    this.players.forEach((p) => { if (p.userId) userMatch.set(p.userId, this); });
    this.broadcast();
    this.nt = setTimeout(() => this.nextRound(), START_MS);
  }
  state(i) {
    const a = this.auction;
    return {
      type: 'match', id: this.id, you: i, now: Date.now(), phase: this.phase, round: this.round, left: this.deck.length,
      slots: SLOTS, budget: BUDGET,
      players: this.players.map((p) => ({ name: p.name, budget: p.budget, squad: p.squad, bot: p.bot, connected: p.bot || !!p.conn, skipped: p.skipped })),
      auction: a ? { card: a.card, bid: a.bid, bidder: a.bidder, endsAt: a.endsAt, elig: a.elig } : null,
      last: this.last, result: this.result,
    };
  }
  broadcast() {
    this.players.forEach((p, i) => { if (p.conn) p.conn.send(JSON.stringify(this.state(i))); });
  }
  nextRound() {
    if (this.over) return;
    const idx = this.deck.findIndex((c) => this.players.some((p) => canBuy(p, c)));
    if (idx < 0) return this.finish();
    const [card] = this.deck.splice(idx, 1);
    this.round++;
    const elig = this.players.map((p) => canBuy(p, card));
    this.players.forEach((p, i) => { p.skipped = !elig[i]; });
    const dur = elig.filter(Boolean).length === 1 ? SOLO_MS : AUCTION_MS; // لو واحد بس يقدر يشتري، المزاد أقصر
    this.auction = { card, bid: card.price, bidder: null, endsAt: Date.now() + dur, elig, botVal: null };
    this.phase = 'auction'; this.last = null;
    clearTimeout(this.t);
    this.t = setTimeout(() => this.resolve(), dur);
    this.broadcast();
    this.botTick();
  }
  bid(i, amount) {
    const a = this.auction, p = this.players[i];
    if (this.phase !== 'auction' || !a || p.skipped || a.bidder === i) return false;
    amount = Math.floor(Number(amount));
    if (!Number.isFinite(amount)) return false;
    const min = a.bidder === null ? a.card.price : a.bid + 1;
    if (amount < min || amount > min + 50 || amount > maxAllowed(p)) return false;
    a.bid = amount; a.bidder = i;
    a.endsAt = Math.max(a.endsAt, Date.now() + EXTEND_MS);
    clearTimeout(this.t);
    this.t = setTimeout(() => this.resolve(), Math.max(50, a.endsAt - Date.now()));
    const other = this.players[1 - i];
    if (!other.skipped && maxAllowed(other) < a.bid + 1) other.skipped = true; // مش هيقدر يزايد أكتر
    if (this.checkEnd()) return true;
    this.broadcast();
    this.botTick();
    return true;
  }
  skip(i) {
    const a = this.auction, p = this.players[i];
    if (this.phase !== 'auction' || !a || p.skipped || a.bidder === i) return false;
    p.skipped = true;
    if (this.checkEnd()) return true;
    this.broadcast();
    return true;
  }
  checkEnd() { // لو محدش تاني يقدر يزايد، المزاد يخلص فورًا
    const a = this.auction;
    const open = this.players.filter((p, i) => !p.skipped && a.bidder !== i);
    if (open.length === 0) { this.resolve(); return true; }
    return false;
  }
  resolve() {
    if (this.over || this.phase !== 'auction') return;
    clearTimeout(this.t);
    this.players.forEach((p) => clearTimeout(p.bt));
    const a = this.auction;
    this.phase = 'between';
    if (a.bidder !== null) {
      const p = this.players[a.bidder];
      p.budget -= a.bid;
      p.squad[freeSlot(p, a.card.pos)] = { ...a.card, paid: a.bid };
      this.unsold = 0;
      this.last = { kind: 'won', by: a.bidder, card: a.card, price: a.bid };
    } else {
      this.unsold++;
      this.last = { kind: 'unsold', card: a.card };
    }
    this.auction = null;
    this.broadcast();
    this.nt = setTimeout(() => {
      if (this.over) return;
      if (this.players.every((p) => emptyCount(p) === 0) || this.unsold >= 10) this.finish(); else this.nextRound();
    }, BETWEEN_MS);
  }
  score(p) { return SLOTS.reduce((s, k) => s + (p.squad[k] ? p.squad[k].r : 0), 0); }
  finish(forfeitIdx = -1) {
    if (this.over) return;
    this.over = true;
    clearTimeout(this.t); clearTimeout(this.nt);
    this.players.forEach((p) => { clearTimeout(p.bt); clearTimeout(p.dcTimer); });
    const scores = this.players.map((p) => this.score(p));
    let winner;
    if (forfeitIdx >= 0) winner = 1 - forfeitIdx;
    else if (scores[0] !== scores[1]) winner = scores[0] > scores[1] ? 0 : 1;
    else if (this.players[0].budget !== this.players[1].budget) winner = this.players[0].budget > this.players[1].budget ? 0 : 1;
    else winner = -1;
    const vsBot = this.players.some((p) => p.bot);
    const rewards = [0, 0];
    const outcome = (i) => (winner === -1 ? 'draw' : winner === i ? 'win' : 'loss');
    this.players.forEach((p, i) => {
      if (p.bot) return;
      const o = outcome(i);
      const coins = vsBot ? { win: 15, loss: 5, draw: 8 }[o] : { win: 50, loss: 10, draw: 25 }[o];
      rewards[i] = coins;
      q.applyResult.run(vsBot ? 0 : +(o === 'win'), vsBot ? 0 : +(o === 'loss'), vsBot ? 0 : +(o === 'draw'), coins, p.userId);
    });
    const [p0, p1] = this.players;
    q.insertMatch.run(p0.name, p1.name, p0.userId, p1.userId, scores[0], scores[1], winner, +vsBot, Date.now());
    this.phase = 'finished'; this.auction = null;
    this.result = { scores, winner, rewards, spent: this.players.map((p) => BUDGET - p.budget), forfeit: forfeitIdx >= 0 ? forfeitIdx : null };
    this.broadcast();
    this.players.forEach((p) => {
      if (!p.userId) return;
      if (userMatch.get(p.userId) === this) userMatch.delete(p.userId);
      const on = online.get(p.userId);
      if (on) on.conn.send(JSON.stringify({ type: 'me', user: publicUser(q.userById.get(p.userId)) }));
    });
  }
  abort() { // لاعب سابها قدام بوت: بدون نتيجة
    this.over = true;
    clearTimeout(this.t); clearTimeout(this.nt);
    this.players.forEach((p) => { clearTimeout(p.bt); clearTimeout(p.dcTimer); if (p.userId && userMatch.get(p.userId) === this) userMatch.delete(p.userId); });
  }
  forfeit(i) {
    if (this.over) return;
    if (this.players.some((p) => p.bot)) { this.abort(); return; }
    this.finish(i);
  }
  // ── البوت ──
  botValue(p, card) {
    const a = this.auction;
    if (a.botVal === null) {
      const fair = card.price * (0.9 + Math.random() * 0.9);
      const perSlot = maxAllowed(p) / emptyCount(p);
      a.botVal = Math.min(fair, perSlot * 2.6 + 4);
    }
    return a.botVal;
  }
  botTick() {
    const a = this.auction;
    if (!a) return;
    this.players.forEach((p, i) => {
      if (!p.bot || p.skipped || a.bidder === i) return;
      clearTimeout(p.bt);
      p.bt = setTimeout(() => {
        const a2 = this.auction;
        if (!a2 || this.over || p.skipped || a2.bidder === i) return;
        const val = this.botValue(p, a2.card);
        const min = a2.bidder === null ? a2.card.price : a2.bid + 1;
        const next = Math.min(a2.bidder === null ? a2.card.price : a2.bid + 1 + Math.floor(Math.random() * 3), maxAllowed(p));
        if (next >= min && next <= val) this.bid(i, next); else this.skip(i);
      }, 1200 + Math.random() * 2200);
    });
  }
}

// ───────────── اللوبي والمطابقة ─────────────
const idleUser = (id) => online.has(id) && !userMatch.has(id);
function startMatch(idA, idB) {
  queue = queue.filter((x) => x !== idA && x !== idB);
  const a = online.get(idA), b = online.get(idB);
  if (!a || !b) return;
  new Match({ userId: idA, name: a.user.username, conn: a.conn }, { userId: idB, name: b.user.username, conn: b.conn });
}
function tryPair() {
  queue = queue.filter(idleUser);
  while (queue.length >= 2) startMatch(queue[0], queue[1]);
}
const sendTo = (id, obj) => { const o = online.get(id); if (o) o.conn.send(JSON.stringify(obj)); };
const broadcastOnline = () => { const m = JSON.stringify({ type: 'online', n: online.size }); online.forEach((o) => o.conn.send(m)); };

function onSocket(conn, req) {
  let me = null;
  let alive = true;
  let tokens = 25, last = Date.now();
  conn.on('pong', () => { alive = true; });
  const hb = setInterval(() => { if (!alive) { conn.terminate(); return; } alive = false; conn.ping(); }, 25000);
  const authTimer = setTimeout(() => { if (!me) conn.close(4001); }, 10000);

  conn.on('message', (raw) => {
    const now = Date.now();
    tokens = Math.min(25, tokens + (now - last) / 40); last = now; // ~25 رسالة/ثانية
    if (tokens < 1) return;
    tokens -= 1;
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (!msg || typeof msg !== 'object') return;
    if (!me) {
      if (msg.type !== 'auth') return;
      const u = userFromToken(msg.token);
      if (!u) { conn.send(JSON.stringify({ type: 'authfail' })); conn.close(4003); return; }
      clearTimeout(authTimer);
      const prev = online.get(u.id);
      if (prev && prev.conn !== conn) { prev.conn.send(JSON.stringify({ type: 'replaced' })); prev.conn.close(4000); }
      me = { id: u.id, name: u.username };
      online.set(u.id, { conn, user: u });
      conn.send(JSON.stringify({ type: 'authed', user: publicUser(u), n: online.size }));
      const m = userMatch.get(u.id);
      if (m && !m.over) {
        const i = m.players.findIndex((p) => p.userId === u.id);
        clearTimeout(m.players[i].dcTimer); m.players[i].conn = conn; m.broadcast();
      }
      broadcastOnline();
      return;
    }
    handle(msg);
  });

  function handle(msg) {
    const m = userMatch.get(me.id);
    const idx = m ? m.players.findIndex((p) => p.userId === me.id) : -1;
    switch (msg.type) {
      case 'queue':
        if (m || queue.includes(me.id)) return;
        queue.push(me.id); conn.send(JSON.stringify({ type: 'queued' })); tryPair(); break;
      case 'unqueue':
        queue = queue.filter((x) => x !== me.id); conn.send(JSON.stringify({ type: 'unqueued' })); break;
      case 'bot':
        if (m) return;
        queue = queue.filter((x) => x !== me.id);
        new Match({ userId: me.id, name: me.name, conn }, { bot: true, name: 'سمسم 🤖' }); break;
      case 'challenge': {
        if (m || typeof msg.to !== 'string') return;
        const target = q.userByName.get(msg.to.trim());
        if (!target || target.id === me.id) return conn.send(JSON.stringify({ type: 'toast', text: 'مفيش لاعب بالاسم ده' }));
        if (!online.has(target.id)) return conn.send(JSON.stringify({ type: 'toast', text: `${target.username} مش أونلاين دلوقتي` }));
        if (!idleUser(target.id)) return conn.send(JSON.stringify({ type: 'toast', text: `${target.username} في ماتش دلوقتي` }));
        const key = `${me.id}>${target.id}`;
        clearTimeout(invites.get(key));
        invites.set(key, setTimeout(() => invites.delete(key), 30000));
        sendTo(target.id, { type: 'invite', from: me.name });
        conn.send(JSON.stringify({ type: 'toast', text: `تم إرسال الدعوة لـ ${target.username} ✉️` })); break;
      }
      case 'inviteReply': {
        if (typeof msg.from !== 'string') return;
        const from = q.userByName.get(msg.from);
        if (!from) return;
        const key = `${from.id}>${me.id}`;
        if (!invites.has(key)) return conn.send(JSON.stringify({ type: 'toast', text: 'الدعوة انتهت' }));
        clearTimeout(invites.get(key)); invites.delete(key);
        if (!msg.accept) return sendTo(from.id, { type: 'toast', text: `${me.name} رفض الدعوة` });
        if (m || !idleUser(from.id)) return conn.send(JSON.stringify({ type: 'toast', text: 'اللاعب مش متاح دلوقتي' }));
        startMatch(from.id, me.id); break;
      }
      case 'bid': if (m) m.bid(idx, msg.amount); break;
      case 'skip': if (m) m.skip(idx); break;
      case 'react': {
        if (!m || !REACTIONS.includes(msg.e)) return;
        const o = m.players[1 - idx];
        if (o.conn) o.conn.send(JSON.stringify({ type: 'react', e: msg.e, from: me.name })); break;
      }
      case 'leave': if (m) m.forfeit(idx); break;
      default: break;
    }
  }

  conn.on('close', () => {
    clearInterval(hb); clearTimeout(authTimer);
    if (!me) return;
    const cur = online.get(me.id);
    if (cur && cur.conn === conn) {
      online.delete(me.id);
      queue = queue.filter((x) => x !== me.id);
      const m = userMatch.get(me.id);
      if (m && !m.over) {
        const i = m.players.findIndex((p) => p.userId === me.id);
        m.players[i].conn = null;
        m.broadcast();
        m.players[i].dcTimer = setTimeout(() => m.forfeit(i), DC_MS);
      }
      broadcastOnline();
    }
  });
}

// ───────────── HTTP ─────────────
const attempts = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const r = attempts.get(ip);
  if (!r || r.reset < now) { attempts.set(ip, { n: 1, reset: now + 10 * 60 * 1000 }); return false; }
  r.n++;
  return r.n > 20;
}
setInterval(() => { const n = Date.now(); attempts.forEach((v, k) => { if (v.reset < n) attempts.delete(k); }); }, 60000).unref();

const NAME_RE = /^[A-Za-z0-9_ء-ي]{3,16}$/;
const clientIp = (req) => (TRUST_PROXY && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress);
const bearer = (req) => (req.headers.authorization || '').replace(/^Bearer /, '');

function json(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', (d) => { s += d; if (s.length > 2048) { req.destroy(); resolve(null); } });
    req.on('end', () => { try { resolve(JSON.parse(s || '{}')); } catch { resolve(null); } });
    req.on('error', () => resolve(null));
  });
}

const INDEX = path.join(__dirname, 'public', 'index.html');
const server = http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  try {
    if (req.method === 'GET' && (url === '/' || url === '/index.html')) {
      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:",
      });
      return fs.createReadStream(INDEX).pipe(res);
    }
    if (req.method === 'GET' && url === '/health') return json(res, 200, { ok: true, online: online.size });
    if (req.method === 'GET' && url === '/api/leaderboard') return json(res, 200, q.board.all());
    if (req.method === 'GET' && url === '/api/me') {
      const u = userFromToken(bearer(req));
      return u ? json(res, 200, publicUser(u)) : json(res, 401, { error: 'غير مسجّل' });
    }
    if (req.method === 'GET' && url === '/api/history') {
      const u = userFromToken(bearer(req));
      if (!u) return json(res, 401, { error: 'غير مسجّل' });
      return json(res, 200, q.history.all(u.id, u.id).map((h) => {
        const mine = h.p1_id === u.id ? 0 : 1;
        return { opponent: mine === 0 ? h.p2 : h.p1, my: mine === 0 ? h.s1 : h.s2, their: mine === 0 ? h.s2 : h.s1,
          result: h.winner === -1 ? 'draw' : h.winner === mine ? 'win' : 'loss', vsBot: !!h.vs_bot, at: h.created };
      }));
    }
    if (req.method === 'POST' && url === '/api/logout') {
      q.delSession.run(sha(bearer(req)));
      return json(res, 200, { ok: true });
    }
    if (req.method === 'POST' && (url === '/api/register' || url === '/api/login')) {
      if (rateLimited(clientIp(req))) return json(res, 429, { error: 'محاولات كتير، جرّب بعد شوية' });
      const b = await readBody(req);
      if (!b || typeof b.username !== 'string' || typeof b.password !== 'string') return json(res, 400, { error: 'بيانات غير صحيحة' });
      const username = b.username.trim(), password = b.password;
      if (url === '/api/register') {
        if (!NAME_RE.test(username)) return json(res, 400, { error: 'الاسم من 3 إلى 16 حرف (عربي/إنجليزي/أرقام/_) بدون مسافات' });
        if (password.length < 6 || password.length > 64) return json(res, 400, { error: 'الباسورد لازم يكون من 6 إلى 64 حرف' });
        if (q.userByName.get(username)) return json(res, 409, { error: 'الاسم ده مستخدم قبل كده' });
        const salt = crypto.randomBytes(16).toString('hex');
        const r = q.insertUser.run(username, salt, hashPassword(password, salt), Date.now());
        const u = q.userById.get(Number(r.lastInsertRowid));
        return json(res, 200, { token: newSession(u.id), user: publicUser(u) });
      }
      const u = q.userByName.get(username);
      if (!u || !checkPassword(password, u)) return json(res, 401, { error: 'الاسم أو الباسورد غلط' });
      return json(res, 200, { token: newSession(u.id), user: publicUser(u) });
    }
    json(res, 404, { error: 'مش موجود' });
  } catch (e) {
    console.error(e);
    if (!res.headersSent) json(res, 500, { error: 'خطأ في السيرفر' });
  }
});
server.on('upgrade', (req, socket) => {
  if (req.url.split('?')[0] !== '/ws') { socket.destroy(); return; }
  handleUpgrade(req, socket, onSocket);
});
process.on('uncaughtException', (e) => console.error('uncaught', e));
process.on('unhandledRejection', (e) => console.error('unhandled', e));
server.listen(PORT, '0.0.0.0', () => console.log(`سمسم جيمز شغال على http://localhost:${PORT}`));
module.exports = { server };
