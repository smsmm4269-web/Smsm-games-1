'use strict';
// WebSocket server صغير بدون مكتبات (RFC 6455): نصوص فقط، ping/pong، إغلاق، تجميع الإطارات.
const crypto = require('node:crypto');
const { EventEmitter } = require('node:events');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_PAYLOAD = 8 * 1024;

class Conn extends EventEmitter {
  constructor(socket) {
    super();
    this.socket = socket;
    this.buf = Buffer.alloc(0);
    this.frags = [];
    this.fragLen = 0;
    this.open = true;
    socket.on('data', (d) => this._onData(d));
    socket.on('close', () => this._closed());
    socket.on('error', () => this._closed());
  }
  _closed() {
    if (!this.open) return;
    this.open = false;
    this.emit('close');
  }
  send(text) {
    if (!this.open) return;
    const payload = Buffer.from(text, 'utf8');
    this._frame(0x1, payload);
  }
  ping() { if (this.open) this._frame(0x9, Buffer.alloc(0)); }
  close(code = 1000) {
    if (!this.open) return;
    const b = Buffer.alloc(2); b.writeUInt16BE(code);
    this._frame(0x8, b);
    this.socket.end();
    setTimeout(() => this.socket.destroy(), 500).unref();
  }
  terminate() { this.socket.destroy(); this._closed(); }
  _frame(opcode, payload) {
    const len = payload.length;
    let head;
    if (len < 126) head = Buffer.from([0x80 | opcode, len]);
    else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[0] = 0x80 | opcode; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
    try { this.socket.write(Buffer.concat([head, payload])); } catch { /* ignore */ }
  }
  _fail(code) { this.close(code); this._closed(); }
  _onData(d) {
    this.buf = Buffer.concat([this.buf, d]);
    if (this.buf.length > MAX_PAYLOAD * 4) return this._fail(1009);
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0;
      const opcode = b[0] & 0x0f;
      const masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f;
      let off = 2;
      if (!masked) return this._fail(1002);
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const big = b.readBigUInt64BE(2); if (big > BigInt(MAX_PAYLOAD)) return this._fail(1009); len = Number(big); off = 10; }
      if (len > MAX_PAYLOAD) return this._fail(1009);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4);
      const data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (opcode === 0x8) { this.close(1000); this._closed(); return; }
      if (opcode === 0x9) { this._frame(0xA, data); continue; }
      if (opcode === 0xA) { this.emit('pong'); continue; }
      if (opcode === 0x1 || opcode === 0x0) {
        this.frags.push(data); this.fragLen += data.length;
        if (this.fragLen > MAX_PAYLOAD) return this._fail(1009);
        if (fin) {
          const full = Buffer.concat(this.frags).toString('utf8');
          this.frags = []; this.fragLen = 0;
          this.emit('message', full);
        }
      } else if (opcode === 0x2) { return this._fail(1003); }
    }
  }
}

function handleUpgrade(req, socket, onConn) {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n' +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
  );
  socket.setNoDelay(true);
  onConn(new Conn(socket), req);
}
module.exports = { handleUpgrade };
